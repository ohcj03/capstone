package com.ximya.basic_chat_ui_implementation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
