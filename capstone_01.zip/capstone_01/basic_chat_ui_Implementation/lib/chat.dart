import 'package:basic_chat_ui_implementation/chat_message_type.dart';

class Chat {
  final String message;
  final ChatMessageType type;
  final DateTime time;

  Chat({required this.message, required this.type, required this.time});

  factory Chat.sent({required message}) =>
      Chat(message: message, type: ChatMessageType.sent, time: DateTime.now());

  static List<Chat> generate() {
    return [
      Chat(
        message: "이걸 혼자 했어요!",
        type: ChatMessageType.sent,
        time: DateTime.now().subtract(const Duration(minutes: 15)),
      ),
      Chat(
        message: "제가!!",
        type: ChatMessageType.sent,
        time: DateTime.now().subtract(const Duration(minutes: 14)),
      ),
      Chat(
        message: "주말에 6시간 동안 헤맸답니다.",
        type: ChatMessageType.sent,
        time: DateTime.now().subtract(const Duration(minutes: 13)),
      ),
      Chat(
        message: "저런 뻘짓하셨군요.",
        type: ChatMessageType.received,
        time: DateTime.now().subtract(const Duration(minutes: 12)),
      ),
      Chat(
        message: "고마워요!",
        type: ChatMessageType.sent,
        time: DateTime.now().subtract(const Duration(minutes: 11)),
      ),
      Chat(
        message: "챗gpt가 없었더라면 상상도 못했겠죠",
        type: ChatMessageType.sent,
        time: DateTime.now().subtract(const Duration(minutes: 10)),
      ),
      Chat(
        message: "안녕하세요 혹시 이번 주 금요일 저녁 6시부터 9시까지 예약 가능할까요??",
        type: ChatMessageType.sent,
        time: DateTime.now().subtract(const Duration(minutes: 9)),
      ),
      Chat(
        message: "안녕하세요 고객님, 해당 시간은 예약 가능하십니다~! 혹시 어떤 서비스 원하시는 지 말씀 해주실 수 있을까요??",
        type: ChatMessageType.received,
        time: DateTime.now().subtract(const Duration(minutes: 8)),
      ),
      Chat(
        message: "산책이랑 목욕 서비스로 혹시 가능할까요?",
        type: ChatMessageType.sent,
        time: DateTime.now().subtract(const Duration(minutes: 7)),
      ),
      Chat(
        message: "물론이죠! 개인정보들 작성해서 보내주시면 되겠습니다. 당일 날 뵐게요!",
        type: ChatMessageType.received,
        time: DateTime.now().subtract(const Duration(minutes: 6)),
      ),
      Chat(
        message: "네네, 강아지 이름은 돌멩이고, 견종은 닥스훈트예요. 잘 부탁드립니다.",
        type: ChatMessageType.sent,
        time: DateTime.now().subtract(const Duration(minutes: 5)),
      ),

    ];
  }


// static List<Chat> generate() {
  //   return [
  //     Chat(
  //       message: "Hello!",
  //       type: ChatMessageType.sent,
  //       time: DateTime.now().subtract(const Duration(minutes: 5)),
  //     ),
  //     Chat(
  //       message: "Nice to meet you!",
  //       type: ChatMessageType.received,
  //       time: DateTime.now().subtract(const Duration(minutes: 4)),
  //     ),
  //     Chat(
  //       message: "The weather is nice today.",
  //       type: ChatMessageType.sent,
  //       time: DateTime.now().subtract(const Duration(minutes: 3)),
  //     ),
  //     Chat(
  //       message: "Yes, it's a great day to go out.",
  //       type: ChatMessageType.received,
  //       time: DateTime.now().subtract(const Duration(minutes: 2)),
  //     ),
  //     Chat(
  //       message: "Have a nice day!",
  //       type: ChatMessageType.sent,
  //       time: DateTime.now().subtract(const Duration(minutes: 1)),
  //     ),
  //   ];
  // }
}
