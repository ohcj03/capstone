enum ChatMessageType {
  sent,
  received,
}
